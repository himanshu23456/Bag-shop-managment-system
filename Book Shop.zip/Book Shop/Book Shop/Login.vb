﻿Public Class Login

    Dim con As New OleDb.OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\Book Shop\Database3.mdb")
    Dim sql As String
    Dim cmd As New OleDb.OleDbCommand
    Dim dt As New DataTable
    Dim da As New OleDb.OleDbDataAdapter
    Dim i As Integer
    Dim a As String
    Dim p As String

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click
        forgot.Show()
        Me.Hide()
        forgot.Activate()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            Dim cmd As OleDb.OleDbCommand = New OleDb.OleDbCommand("SELECT  * FROM userinfo  WHERE username = '" & TextBox1.Text & "' and pass='" & TextBox3.Text & "' ", con)
            Dim user As String = ""
            Dim pass As String = ""
            con.Open()

            Dim reader As OleDb.OleDbDataReader = cmd.ExecuteReader()
            If (reader.Read() = True) Then
                user = reader("username")
                pass = reader("pass")
                MessageBox.Show("User Login Successful!")
                mainform.Show()
                mainform.Activate()
            Else
                TextBox1.Clear()
                TextBox3.Clear()
                MsgBox("Invalid username and password!")
            End If
            reader.Close()
            con.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Signup.Show()
        Signup.Activate()
        Me.Hide()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        End
    End Sub

    Private Sub Login_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class