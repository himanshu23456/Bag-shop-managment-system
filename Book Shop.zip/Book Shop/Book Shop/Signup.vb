﻿Public Class Signup
    Dim con As New OleDb.OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\Book Shop\Database3.mdb")
    Dim sql As String
    Dim cmd As New OleDb.OleDbCommand
    Dim dt As New DataTable
    Dim da As New OleDb.OleDbDataAdapter
    Dim i As Integer

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            con.Open()
            sql = "INSERT INTO userinfo (uname,username,email,pass,contactno) values ('" & TextBox1.Text & "', '" & TextBox2.Text & "','" & TextBox5.Text & "','" & TextBox6.Text & "','" & TextBox4.Text & "')"
            cmd.Connection = con
            cmd.CommandText = sql
            i = cmd.ExecuteNonQuery
            If i > 0 Then
                MsgBox("New User Signed Up successfully!")
            ElseIf TextBox1.Text = "" Or TextBox2.Text = "" Or TextBox4.Text = "" Or TextBox5.Text = "" Or TextBox6.Text = "" Then
                MsgBox("User Sign Up Unsuccessful....! Please enter a valid data.")
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            con.Close()
        End Try

        Me.Hide()
        Login.Show()
    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click
        Me.Hide()
        Login.Show()
        Login.Activate()
    End Sub

    Private Sub Signup_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class